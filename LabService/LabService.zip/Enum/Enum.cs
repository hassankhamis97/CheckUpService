﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabService.Enum
{

    public enum Response
    {
        Success = 1,
        Fail = 2
    };

}