﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabService.Model
{
    public class UserTest
    {
        public long TestId { get; set; }
        public string UserId { get; set; }
    }
}