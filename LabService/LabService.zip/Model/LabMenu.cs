﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabService.Model
{
    public class LabMenu
    {
        public string idFB { get; set; }
        public string hotline { get; set; }
        public string labPhoto { get; set; }
        public string labName { get; set; }
        public double rating { get; set; }

    }
}