﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabService.Model
{
    public class NofificationBadge
    {
        public int requestBadge { get; set; }
        public int resultBadge { get; set; }
    }
}